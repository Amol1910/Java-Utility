
public class TestChk {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String str="144.123";
		System.out.println(str.startsWith("144.1235555"));

	}

}
